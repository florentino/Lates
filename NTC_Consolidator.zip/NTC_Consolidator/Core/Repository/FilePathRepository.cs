﻿using NTC_Consolidator.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NTC_Consolidator.NTC_Model;
using NTC_Consolidator.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;

namespace NTC_Consolidator.Core.Repository
{
    public class FilePathRepository : IFilePathRepository, IDisposable
    {
        private NTC_Context_Entities context;
        DbSet<BDOLF_PathMaintenance> _bjectSet;

        public FilePathRepository(NTC_Context_Entities context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_PathMaintenance>();
        }

        public void BulkDelete(object objdata)
        {
            throw new NotImplementedException();
        }

        public void BulkInsert(object objdata)
        {
            throw new NotImplementedException();
        }

        public void BulkUpdete(object objdata)
        {
            throw new NotImplementedException();
        }

        public void DeleteFilePathMaintenace(string PathID)
        {
            BDOLF_PathMaintenance filePathMaintenance = context.BDOLF_PathMaintenance.Find(PathID);
            context.BDOLF_PathMaintenance.Remove(filePathMaintenance);
        }

        public void DeleteFilePathMaintenace(int PathID)
        {
            BDOLF_PathMaintenance filePathMaintenance = context.BDOLF_PathMaintenance.Find(PathID);
            context.BDOLF_PathMaintenance.Remove(filePathMaintenance);
        }

        public void TruncateTable()
        {
            var result = context.BDOLF_PathMaintenance.Any();

            if (result)
            {
                var allRecord = from item in context.BDOLF_PathMaintenance select item;
                context.BDOLF_PathMaintenance.RemoveRange(allRecord);
                context.SaveChanges();
            }
        }

        public IEnumerable<BDOLF_PathMaintenance> GetAll()
        {
            var query = from data in context.BDOLF_PathMaintenance.ToList()
                        select data;

            return query;
        }

        public BDOLF_PathMaintenance GetByCode(string PathID)
        {
            return context.Set<BDOLF_PathMaintenance>().Find(PathID);
        }

        public BDOLF_PathMaintenance GetByID(int PathID)
        {
            return context.Set<BDOLF_PathMaintenance>().Find(PathID);
            //return context.BDOLF_PathMaintenance.Select(a => a.PathID == PathID).ToList();
        }

        public void InsertFilePathMaintenace(BDOLF_PathMaintenance main)
        {
            context.Set<BDOLF_PathMaintenance>().Add(main);
            //if (context.Set<BDOLF_PathMaintenance>().Any(e => e.PathID == main.PathID))
            //{
            //    context.Entry(main).State = EntityState.Modified;
            //}
            //else
            //{
            //    context.Entry(main).State = EntityState.Added;
            //}

            //context.SaveChanges();
        }

        public void UpdateFilePathMaintenace(BDOLF_PathMaintenance main)
        {
            context.Entry(main).State = EntityState.Detached;
            context.Set<BDOLF_PathMaintenance>().Add(main);
        }

        public void Save()
        {
            try
            {
                context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        System.Console.WriteLine("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
            }
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

    }
}
