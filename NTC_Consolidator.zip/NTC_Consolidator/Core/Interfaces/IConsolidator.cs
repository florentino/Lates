﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Interfaces
{
    public interface IConsolidator : IDisposable
    {
        IEnumerable<BDOLF_NTC_Consolidator> GetAll();
        BDOLF_NTC_Consolidator GetByID(int TransID);
        BDOLF_NTC_Consolidator GetByCode(string AccountNo);
        void InsertFilePathMaintenace(BDOLF_NTC_Consolidator ntc);
        void DeleteFilePathMaintenace(int AccountNo);
        void TruncateTable();
        IEnumerable<BDOLF_NTC_Consolidator> GetTopOne();
        void DeleteFilePathMaintenace(string AccountNo);
        void UpdateFilePathMaintenace(BDOLF_PathMaintenance ntc);
        void BulkInsert(object[] objdata);
        void BulkDelete(object[] objdata);
        void BulkUpdete(object[] objdata);
        void Save();
    }
}
