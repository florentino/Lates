﻿using NTC_Consolidator.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NTC_Consolidator.Data;
using System.Data.Entity;

namespace NTC_Consolidator.Core.Repository
{
    public class ExchangeRateRepository : IExchangeRate, IDisposable
    {
        private NTC_Context_Entities context;
        DbSet<BDOLF_ExchangeRate> _bjectSet;

        public ExchangeRateRepository(NTC_Context_Entities context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_ExchangeRate>();
        }


        public void BulkDelete(object objdata)
        {
            throw new NotImplementedException();
        }

        public void BulkInsert(object objdata)
        {
            throw new NotImplementedException();
        }

        public void BulkUpdete(object objdata)
        {
            throw new NotImplementedException();
        }

        public void DeleteFilePathMaintenace(string CurrencyCode)
        {
            throw new NotImplementedException();
        }

        public void DeleteFilePathMaintenace(int CurrencyID)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_ExchangeRate> GetAll()
        {
            var query = from data in context.BDOLF_ExchangeRate.ToList()
                        select data;

            return query;
        }

        public BDOLF_ExchangeRate GetByCode(string CurrencyCode)
        {
            // var result = uow.ExchangeRateRepository.GetAll().Where(i => i.CurrencyCode == code).FirstOrDefault().CurrencyRate;
            var result = context.BDOLF_ExchangeRate.Where(a => a.CurrencyCode == CurrencyCode).FirstOrDefault();
            return result;
        }

        public BDOLF_ExchangeRate GetByID(int PathID)
        {
            throw new NotImplementedException();
        }

        public void InsertFilePathMaintenace(BDOLF_ExchangeRate gl)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }

        public void TruncateTable()
        {
            throw new NotImplementedException();
        }

        public void UpdateFilePathMaintenace(BDOLF_ExchangeRate gl)
        {
            throw new NotImplementedException();
        }
    }
}
