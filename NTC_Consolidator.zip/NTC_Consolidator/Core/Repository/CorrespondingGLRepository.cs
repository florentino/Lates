﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Data;
using NTC_Consolidator.Model;
using System.Data.Entity;

namespace NTC_Consolidator.Core.Repository
{
    public class CorrespondingGLRepository : ICorrespondingGLRepository, IDisposable
    {
        private NTC_Context_Entities context;
        DbSet<CorrespondingGL> _bjectSet;

        public CorrespondingGLRepository(NTC_Context_Entities context)
        {
            this.context = context;
            _bjectSet = context.Set<CorrespondingGL>();
        }

        public void BulkDelete(object objdata)
        {
            throw new NotImplementedException();
        }

        public void BulkInsert(object objdata)
        {
            throw new NotImplementedException();
        }

        public void BulkUpdete(object objdata)
        {
            throw new NotImplementedException();
        }

        public void DeleteCorrespondingGL(string GLCode)
        {
            BDOLF_CorrepondingGL gl = context.BDOLF_CorrepondingGL.Find(GLCode);
            context.BDOLF_CorrepondingGL.Remove(gl);
        }

        public void DeleteCorrespondingGL(int GLCodeID)
        {
            //BDOLF_CorrepondingGL gl = context.BDOLF_CorrepondingGL.Find(GLCodeID);
            //context.BDOLF_CorrepondingGL.Remove(gl);
            throw new NotImplementedException();
        }

        public CorrespondingGL GetCorrespondingGLByID(string glCode)
        {
           return context.Set<CorrespondingGL>().Find(glCode);
        }

        public CorrespondingGL GetCorrespondingGLByID(int glID)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CorrespondingGL> GetGL()
        {
            //var data = context.BDOLF_CorrepondingGL.Where(a => a.isDeleted == false);
            return context.Set<CorrespondingGL>().ToList();
        }

        public void InsertCorrespondingGL(CorrespondingGL gl)
        {
           // context.BDOLF_CorrepondingGL.Add(gl);
            context.Set<CorrespondingGL>().Add(gl);
        }
        
        public void UpdateCorrespondingGL(CorrespondingGL gl)
        {
            context.Entry(gl).State = EntityState.Modified;
        }

        public void Save()
        {
            context.SaveChanges();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
