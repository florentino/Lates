﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Interfaces
{
    public interface IExchangeRate : IDisposable
    {

        IEnumerable<BDOLF_ExchangeRate> GetAll();
        BDOLF_ExchangeRate GetByID(int CurrencyID);
        BDOLF_ExchangeRate GetByCode(string CurrencyCode);
        void InsertFilePathMaintenace(BDOLF_ExchangeRate gl);
        void DeleteFilePathMaintenace(int CurrencyID);
        void TruncateTable();
        void DeleteFilePathMaintenace(string CurrencyCode);
        void UpdateFilePathMaintenace(BDOLF_ExchangeRate gl);
        void BulkInsert(object objdata);
        void BulkDelete(object objdata);
        void BulkUpdete(object objdata);
        void Save();
    }
}
