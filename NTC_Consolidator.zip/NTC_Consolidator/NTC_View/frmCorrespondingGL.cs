﻿using MetroFramework;
using MetroFramework.Forms;
using NTC_Consolidator.Model;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;


namespace NTC_Consolidator.NTC_View
{
    public partial class frmCorrespondingGL : MetroForm
    {
        SaveFileDialog diag = new SaveFileDialog();
        DataTable dt = new DataTable();
        string filename = "";
        bool isEnabled = false;

        private static frmCorrespondingGL glform = null;

        public static frmCorrespondingGL Instance()
        {
            if (glform == null)
            {
                glform = new frmCorrespondingGL();
            }
            return glform;
        }

        public frmCorrespondingGL()
        {
            //if (Program.Role != "Accounting")
            //{
            //    MetroMessageBox.Show(this, "\r\n\r\nSorry, You dont have a permission to access this module, Please contact your system administrator", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    Application.Exit();
            //}
           
            isEnabled = false;
            InitializeComponent();
        }

        private void frmCorrespomdingGL_Load(object sender, EventArgs e)
        {
            ////////lblBusy.Text = "";

            ////////var _instance = new NTCService();

            ////////dt = _instance.GetAllGLRecord();

            ////////Search(txtSearch.Text);
            ////////cmbStatus.SelectedIndex = 0;
            // EnableDisabledFields(false);
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //isEnabled = true;
            //EnableDisabledFields(isEnabled);

            //btnSubmit.Text = isEnabled == false ? "&Add New Record" : "&Submit";
            
            var isPassed = false;
            var _system = cmbSysTagging.SelectedItem != null ? cmbSysTagging.SelectedItem.ToString() : "";
            var _status = cmbStatus.SelectedItem != null ? cmbStatus.SelectedItem.ToString() : "";
            var txtcode = txtGLCode.Text;
            var txtname = txtGLName.Text;
            var product = txtProductDesc.Text;


            #region CorrespondingGL Validation Using EF DataAnnotation

            CorrespondingGL gl = new CorrespondingGL();

            isPassed = IsValid(isPassed, txtcode, txtname, gl, _system, _status, product); //Check for Valid Input

            if (!isPassed)
            {
                return;
            }
            else
            {
                //validate first before saving
                //////var _instance = new NTCService();

                var retval = 0;// _instance.InsertGL(txtcode, txtname, Program.UserName, _system, _status, product);

                if (retval == 1)//retval == 1 Successfully saved
                {
                    #region Load Data into datagrid
                    dt =  null;// _instance.GetAllGLRecord();
                    Search(txtSearch.Text); 
                    #endregion

                    MetroMessageBox.Show(this, "\r\n\r\nSuccessfully saved", "Correponding GL", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    cmbStatus.SelectedIndex = 0;
                    cmbSysTagging.SelectedIndex = -1;
                    txtProductDesc.Text =
                    txtGLCode.Text = "";
                    txtGLName.Text = "";
                }
                else if (retval == 0) //retval == 0 GL Code Already Exist
                {
                    MetroMessageBox.Show(this, "\r\n\r\nGL Code Already Exist in the Database", "Exists", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (retval == 2) //retval == 2 error encountered
                {
                    MetroMessageBox.Show(this, "\r\n\r\nError encountered, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }

            #endregion
        }

        private void EnableDisabledFields(bool _isEnabled)
        {
            cmbSysTagging.Enabled = _isEnabled;
            txtGLCode.Enabled = _isEnabled;
            txtGLName.Enabled = _isEnabled;
            txtProductDesc.Enabled = _isEnabled;
            cmbStatus.Enabled = _isEnabled;
        }
        
        private bool IsValid(bool isPassed, string txtcode, string txtname, CorrespondingGL gl, string system, string status, string product)
        {
            isPassed = true;

            try
            {
                if (string.IsNullOrEmpty(txtcode))
                {
                    gl.GLCode = "";
                }
                else
                {
                    lblErrGLCode.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrGLCode.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(txtname))
                {
                    gl.GLName = "";
                }
                else
                {
                    lblErrGLName.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrGLName.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(status))
                {
                    gl.Status = "";
                }
                else
                {
                    lblErrStatus.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrStatus.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(system))
                {
                    gl.System = "";
                }
                else
                {
                    lblErrSystemTagging.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrSystemTagging.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(product))
                {
                    gl.ProductDesc = "";
                }
                else
                {
                    lblErrProductDesc.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrProductDesc.Text = ex.Message;
                isPassed = false;
            }
            return isPassed;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            Search("");
        }

        private void Search(string keyword)
        {
            if (!string.IsNullOrEmpty(keyword))
            {
                DataView dv = new DataView(dt);
                dv.RowFilter = "GLCode LIKE '%" + keyword + "%' OR GLName LIKE '%" + keyword + "%' OR CreatedBy LIKE '%" + keyword + "%'";

                metroGridGL.DataSource = dv;
            }
            else
            {
                metroGridGL.DataSource = dt;
            }
            this.metroGridGL.Columns["GLName"].Width = 180;
            this.metroGridGL.Columns["RowID"].Visible = false;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            Search(txtSearch.Text);
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            // Check if the backgroundWorker is already busy running the asynchronous operation
            if (!backgroundWorker1.IsBusy /*&& fileValidatedAndNoErrors*/)
            {
                ExportToExcel();
            }
            else
            {
                lblBusy.Text = "Busy processing, Please wait...";
            }
        }

        private void ExportToExcel()
        {
            // Stream myStream;
            diag.Filter = "Excel|*.xls|Excel 2010|*.xlsx";
            diag.Title = "Save Corresponding GL";
            diag.ShowDialog();
            filename = Path.GetFileName(diag.FileName);

            if (diag.FileName != "")
            {
                // This method will start the execution asynchronously in the background
                backgroundWorker1.RunWorkerAsync();
            }
        }

        private void backgroundWorker1_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            //open file
            StreamWriter wr = new StreamWriter(diag.FileName, false, Encoding.Unicode);

            try
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    wr.Write(dt.Columns[i].ToString().ToUpper() + "\t");
                }

                wr.WriteLine();

                //write rows to excel file
                for (int i = 0; i < (dt.Rows.Count); i++)
                {
                    Thread.Sleep(1000);
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        if (dt.Rows[i][j] != null)
                        {
                            wr.Write("" + Convert.ToString(dt.Rows[i][j]) + "" + "\t");
                        }
                        else
                        {
                            wr.Write("\t");
                        }

                        if (backgroundWorker1.WorkerSupportsCancellation == true)
                        {
                            backgroundWorker1.CancelAsync();
                        }

                    }
                    //go to next line
                    wr.WriteLine();
                }
                //close file
                wr.Close();
            }
            catch (Exception ex)
            {
                lblBusy.Text = "";
                MetroMessageBox.Show(this, "\r\n\r\nError encountered while generating the excel file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            lblBusy.Text = "";

            MetroMessageBox.Show(this, "\r\n\r\n" + filename + " file was successfully generated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void deleteRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            if (this.metroGridGL.SelectedRows.Count > 0)
            {
                var rowSelected = this.metroGridGL.SelectedRows[0].Index;

                DialogResult responseDlg = MetroMessageBox.Show(this, "\r\n\r\nAre you sure, You want to delete this GL Code (" + metroGridGL.Rows[rowSelected].Cells["GLCode"].Value + ") in the system?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (responseDlg == DialogResult.Yes)
                {
                    metroGridGL.Rows.RemoveAt(rowSelected);
                    DeleteItem(rowSelected);
                    MetroMessageBox.Show(this, "\r\n\r\n" + metroGridGL.Rows[rowSelected].Cells["GLCode"].Value + " has been removed", "Remove Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void DeleteItem(int rowSelected)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow recRow = dt.Rows[i];
                if (recRow["RowID"].ToString() == rowSelected.ToString())
                {
                    dt.Rows.Remove(recRow);
                    dt.AcceptChanges();
                    break;
                }
            }
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (metroGridGL.Rows.Count > 0)
            {
                //txtGLCode.Text = metroGridGL.SelectedRows.Cells[0].Value;
                //textclient.Value = metroGridGL.SelectedRows(0).Cells(1).Value;
                //textdatetime.Value = dataGrid1.SelectedRows(0).Cells(2).Value;
                //textcombobox.Value = dataGrid1.SelectedRows(0).Cells(3).Value;
            }
        }
    }
}
